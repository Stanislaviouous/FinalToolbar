package com.example.toolbarapp.ui.rating;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.example.toolbarapp.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import static java.util.Map.Entry.comparingByValue;

public class RatingFragment extends Fragment {

    HashMap<String, Integer> map = new HashMap<String, Integer>();
    private ArrayList<Rating> ratingList;
    private RatingViewModel ratingViewModel;
    private DatabaseReference rootRot;
    ListView listView;
    String t;
    /*
    * */
    String loginRat, countRat, imageUriRat;
    Integer number;
    /*
    * */
    public View onCreateView(@NonNull final LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ratingViewModel = ViewModelProviders.of(this).get(RatingViewModel.class);
        View root = inflater.inflate(R.layout.fragment_rating, container, false);

        rootRot = FirebaseDatabase.getInstance().getReference();
        listView = root.findViewById(R.id.list_rating);
        ratingUpdate();
        
        return root;
    }
    void ratingUpdate(){
        ratingList = new ArrayList<>();
        rootRot.child("Rating").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String currentUserID = new String();

                for (DataSnapshot childDataSnapshot : snapshot.getChildren()) {
                    map.put(childDataSnapshot.getKey(), childDataSnapshot.getValue(Integer.class));
                    currentUserID = childDataSnapshot.getKey();
                }

                List<Integer> mapValues = new ArrayList<>(map.values());
                Collections.sort(mapValues);
                System.out.println(map);

                /* Набросок
                *
                * */
                rootRot.child("Users").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        int r = 1;
                        for (DataSnapshot childDataSnapshotHost : dataSnapshot.getChildren()) {
                            if (childDataSnapshotHost.child("email").exists() && childDataSnapshotHost.child("image").exists()) {
                                imageUriRat = (String) childDataSnapshotHost.child("image").getValue();
                                countRat = (String) childDataSnapshotHost.child("count").getValue();
                                loginRat = (String) childDataSnapshotHost.child("login").getValue();
                                t = String.valueOf(r);
                                ratingList.add(new Rating(t, loginRat, countRat, imageUriRat));
                                r++;
                            }
                        }
                        ratingList.add(new Rating("", "", "", ""));
                        final RatingAdapter ratingAdapter = new RatingAdapter(getContext(), R.layout.list_item, ratingList);
                        listView.setAdapter(ratingAdapter);
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
                /*
                ratingList.add(new Rating(1, loginRat, countRat, imageUriRat));
                final RatingAdapter ratingAdapter = new RatingAdapter(getContext(), R.layout.list_item, ratingList);
                listView.setAdapter(ratingAdapter);*/
                /*
                * */

            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
    void dataUser(){

    }
}

/*String currentUserID = ProfileFragment.mAuth.getCurrentUser().getUid();
        rootRot.child("Users").child(currentUserID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("email").exists() && dataSnapshot.child("image").exists()) {
                    imageUriRat = (String) dataSnapshot.child("image").getValue();
                    countRat = (String) dataSnapshot.child("count").getValue();
                    loginRat = (String) dataSnapshot.child("login").getValue();

                    ratingList.add(new Rating(1, loginRat, countRat, imageUriRat));
                    final RatingAdapter ratingAdapter = new RatingAdapter(getContext(), R.layout.list_item, ratingList);
                    listView.setAdapter(ratingAdapter);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });*/