package com.example.toolbarapp.ui.rating;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class RatingViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public RatingViewModel() {
    }
    public LiveData<String> getText() {
        return mText;
    }
}