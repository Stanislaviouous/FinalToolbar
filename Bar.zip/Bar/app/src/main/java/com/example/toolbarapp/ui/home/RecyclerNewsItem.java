package com.example.toolbarapp.ui.home;

public class RecyclerNewsItem {
    private String title = "";
    private String textSoul = "";

    public RecyclerNewsItem(String title, String textSoul) {
        this.title = title;
        this.textSoul = textSoul;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return textSoul;
    }

    public void setDescription(String description) {
        this.textSoul = description;
    }
}
