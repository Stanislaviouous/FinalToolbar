package com.example.toolbarapp.ui.home;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.toolbarapp.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class RecyclerVideoViewAdapter extends RecyclerView.Adapter<RecyclerVideoViewAdapter.ViewHolder> {


    private ArrayList<String> VideoUrls = new ArrayList<>();
    private Context mContext;

    public RecyclerVideoViewAdapter(Context context, ArrayList<String> imageUrls) {
        VideoUrls = imageUrls;
        mContext = context;
    }

    @NonNull
    @Override
    public RecyclerVideoViewAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_image_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        // "<iframe src=\"https://vk.com/video_ext.php?oid=7226707&id=171238460&hash=9068a2aa618144c7&hd=1\" width=\"112\" height=\"63\" frameborder=\"0\" allowfullscreen></iframe>"


    }

    @Override
    public int getItemCount() {
        return VideoUrls.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        WebView video;
        WebView videoAll;
        public ViewHolder(View itemView) {
            super(itemView);
            videoAll = itemView.findViewById(R.id.videoView);
            video = itemView.findViewById(R.id.recy_video);
        }
    }
}
