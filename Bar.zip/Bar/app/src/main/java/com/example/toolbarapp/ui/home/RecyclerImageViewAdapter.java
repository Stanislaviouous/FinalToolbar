package com.example.toolbarapp.ui.home;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.toolbarapp.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class RecyclerImageViewAdapter extends RecyclerView.Adapter<RecyclerImageViewAdapter.ViewHolder> {


    private ArrayList<String> ImageUrls = new ArrayList<>();
    private Context mContext;

    public RecyclerImageViewAdapter(Context context, ArrayList<String> imageUrls) {
        ImageUrls = imageUrls;
        mContext = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_image_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

         Picasso.get().load(ImageUrls.get(position)).into(holder.image);

         holder.image.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
             }
         });
    }


    @Override
    public int getItemCount() {
        return ImageUrls.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView image;
        ImageView imageAll;
        public ViewHolder(View itemView) {
            super(itemView);
            imageAll = itemView.findViewById(R.id.imageViewPos);
            image = itemView.findViewById(R.id.recy_image);
        }
    }
}
