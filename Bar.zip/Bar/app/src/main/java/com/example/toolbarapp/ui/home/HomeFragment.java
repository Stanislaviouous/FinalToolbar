package com.example.toolbarapp.ui.home;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.toolbarapp.MainActivity;
import com.example.toolbarapp.R;
import com.example.toolbarapp.aide.OnSwipeTouchListener;
import com.example.toolbarapp.map.MapsActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class HomeFragment extends Fragment {
    HomeViewModel homeViewModel;
    RecyclerView recyclerView;
    NewsAdapter adapter;
    List<RecyclerNewsItem> recyclerNewsItemList;

    @SuppressLint("ClickableViewAccessibility")
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        final View root = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = (RecyclerView) root.findViewById(R.id.recyclerViewNews);
        recyclerView.setLayoutManager(new LinearLayoutManager(root.getContext()));
        recyclerView.setHasFixedSize(true);
        recyclerNewsItemList = new ArrayList<>();

        /*for (int i = 0; i<6; i++) {
            recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert" + " " + (i + 1), "\"Внимание! Помогите найти!\n" +
                    "Пропал #Кругликов Андрей Анатольевич, 52 года (1968 г.р.)\n" +
                    "п. Майский, Белгородский р-он, Белгородская обл.\n" +
                    "с сентября 2020 года его местонахождение неизвестно.\n" +
                    "Всем, кто располагает информацией о местонахождении пропавшего, просьба сообщить на горячую линию Отряда 88007005452 или в полицию 02, 102. Просьба содействовать репостом"));
        }*/
        // Подвесить на API

        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert" , "\"Внимание! Помогите найти!\n" +
                "Пропал #Кругликов Андрей Анатольевич, 52 года (1968 г.р.)\n" +
                "п. Майский, Белгородский р-он, Белгородская обл.\n" +
                "с сентября 2020 года его местонахождение неизвестно.\n" +
                "Всем, кто располагает информацией о местонахождении пропавшего, просьба сообщить на горячую линию Отряда 88007005452 или в полицию 02, 102. Просьба содействовать репостом"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "Деятельность поискового отряда неразрывно связана с работой правоохранительных органов.\n" +
                "Наше сотрудничество с годами становится более слаженным и плодотворным. Мы надеемся, что такая тенденция будет не только сохраняться, но и развиваться.\n" +
                "За активное содействие и помощь в поисках пропавших людей добровольцам отряда ЛизаАлерт Липецкой области были вручены благодарственные письма от врио начальника Управления уголовного розыска по Липецкой области и начальника ОМВД России по Грязинскому району Липецкой области.\n" +
                "Поисково-спасательный отряд ЛизаАлерт Липецк благодарит сотрудников полиции и надеется на дальнейшее активное сотрудничество."));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "#Пропал человек!\n" +
                "#Губайдулин Владислав Максимович, 18 лет (2002 г.р.)\n" +
                "г. #Брянск .\n" +
                "С 27 января 2021 года его местонахождение неизвестно.\n" +
                "Может находится в вашем районе!\n" +
                "Всем, кто располагает сведениями о пропавшем, просьба позвонить по телефонам 88007005452 (Горячая линия ЛА) или 02, 102 (полиция).\n" +
                "#Пропал_человек\n" +
                "#Помогите_найти\n" +
                "#Помощь\n" +
                "#Поиск\""));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "А мы продолжаем &#129418;\n" +
                "#ШколаЛизаАлерт приглашает детей от 7 до 10 лет на тренинг по безопасности «Что делать, если я потерялся?»\n" +
                "Когда? 30.01.2021 в 12:00 (по мск)\n" +
                "Где? Вход по ссылке* https://cppl.webex.com/cppl/j.php?MTID=mf5679f3dd858343cec8e22d8f024e832\n" +
                "*вход на мероприятие будет открыт с 11:50."));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "Внимание! Помогите найти человека!\n" +
                "Пропала #Шевчук (#Урюпина) Галина Николаевна, 67 лет\n" +
                "с. #Новый_Ольшанец, #Елец`кий р-н, #Липецкая_область\n" +
                "С 4 января 2021 года ее местонахождение неизвестно.\n" +
                "#LizaAlert #ЛизаАлерт #Пропал_человек"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "В период с 18 по 20 января 2021 года добровольцы отряда #ЛизаАлерт патрулировали улицы в вечернее и ночное время в городах Липецкой области. Главная цель - предотвратить и уменьшить количество людей, попавших в сложную ситуацию в морозные дни.\n" +
                "Спасибо всем участникам \"Ночного патруля\", которые не остались равнодушными и оказали необходимую помощь людям.\n" +
                "Если Вы встретите таких людей - поинтересуйтесь, все ли у них в порядке и не нуждаются ли они в помощи.\n" +
                "В случае необходимости, звоните по телефонам:\n" +
                "Единый телефон экстренных служб – 112\n" +
                "Горячая линия ЛизаАлерт – 8-800-700-54-52\n" +
                "Помочь может каждый!\n" +
                "Тема: https://lizaalert.org/forum/viewtopic.php?f=272&t=42761&p=434963#p434963\n" +
                "#ЛизаАлерт #НочнойПатруль #LizaAlert #Липецкаяобласть #помочьможеткаждый"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "Внимание! Помогите найти человека!\n" +
                "Пропал #Сургутсков Валерий Николаевич, 68 лет г. #Липецк\n" +
                "С декабря 2020 года его местонахождение неизвестно.\n" +
                "Инфорги: Ленец (Елена) 89513000159, Бонни (Анна) 89191677293\n" +
                "Тема на форуме: https://vk.cc/bXyKyL\n" +
                "#LizaAlert #ЛизаАлерт #Пропал_человек"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "ВНИМАНИЕ! ПОМОГИТЕ НАЙТИ ЧЕЛОВЕКА!\n" +
                "ОБНОВЛЕННАЯ ОРИЕНТИРОВКА!\n" +
                "Пропал #Дмитриев Сергей Владимирович, 47 лет.\n" +
                "г. Балашиха, Московская обл.\n" +
                "С 14 ноября его местонахождение неизвестно.\n" +
                "Есть информация, что он может находиться в Малоярославецком р-не, Калужской обл.\n" +
                "Инфорги: Ольга 89109185360, Елена 89056427417\n" +
                "Тема на форуме: https://vk.cc/bWo8qj"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "Пропал Сотников Сергей Валерьевич, 32 года, г. Липецк. - ::ЛизаАлерт:: Поисково-спасательный отряд"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "Внимание! Помогите найти человека!\n" +
                "Пропал #Потапов Сергей Иванович, 63 года, г. #Липецк\n" +
                "С 16 января 2021 года его местонахождение неизвестно.\n" +
                "Инфорг: Киви Ирина 89046862938\n" +
                "Тема на форуме:https://vk.cc/bXmHfd\n" +
                "#LizaAlert #ЛизаАлерт #Пропал_человек"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "Новичковая отряда #ЛизаАлерт проводит онлайн-встречу в четверг 21 января 2021 года в 18:00.\n" +
                "Для тех, кто давно следит за деятельностью отряда, но никак не решается начать нам помогать. Для тех, кто все для себя решил, но не знает, с чего начинать. А еще это будет интересно тем, кто уже ездил на поиски, но остались вопросы!\n" +
                "Мы были бы рады позвать вас на очную встречу, но из-за сложной эпидемиологической обстановки готовы пока только на онлайн-формат.\n" +
                "Встреча пройдет на платформе Webinar.ru.\n" +
                "Необходимо зарегистрироваться по ссылке: https://events.webinar.ru/6168613/7808659.\n" +
                "Вам придет приглашение на почту. Вопросы во время встречи можно будет задавать в чате трансляции. Мы ждем вас!"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "Спасибо нашему постоянному партнёру, сеть магазинов Пятёрочка, за подаренную нам карту с начисленными баллами, с помощью которых мы смогли приобрести чай, кофе, сахар, полезные перекусы и много еще всего необходимого для длительных поисков и выездов.\n" +
                "#Пятёрочка #спасибоотлизаалерт"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "Внимание! Помогите найти человека!\n" +
                "Пропал #Суравикин Александр Александрович, 27 лет г. #Липецк\n" +
                "С 26 декабря 2020 года его местонахождение неизвестно.\n" +
                "Инфорги: Ленец (Елена) 89513000159, Бонни (Анна) 89191677293\n" +
                "Тема на форуме: https://vk.cc/bXiT8L\n" +
                "#LizaAlert #ЛизаАлерт #Пропал_человек"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "Внимание! Помогите найти человека!\n" +
                "Пропала #Симонова Галина Андреевна, 73 года\n" +
                "г. #Липецк\n" +
                "С 26 декабря 2020 года ее местонахождение неизвестно.\n" +
                "#LizaAlert #ЛизаАлерт #Пропал_человек"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "Внимание! Помогите найти человека!\n" +
                "Пропала #Еремеева (#Николаева) Валентина Васильевна, 61 год\n" +
                "с. #Ратчино, #Добровский_район, #Липецкая_область\n" +
                "5 января 2021 года вышла из дома и не вернулась.\n" +
                "Инфорг: Оксана (Окса) 89042952445\n" +
                "Тема на форуме: https://vk.cc/bXi4Mp\n" +
                "#LizaAlert #ЛизаАлерт #Пропал_человек"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "\"Внимание! Помогите найти человека!\n" +
                "Пропал #Голубов Игорь Евгеньевич, 48 лет\n" +
                "#Куйбышевский_район , #Ростовская_область - г. #Липецк\n" +
                "С 30 декабря 2020 года его местонахождение неизвестно.\n" +
                "#LizaAlert #ЛизаАлерт #Пропал_человек"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "\"Новогодние каникулы закончились, и дети вернулись на занятия в школы и детские садики. За пределами своего дома очень важно помнить о правилах безопасности, и мы с радостью анонсируем старт занятий от #ШколаЛизаАлерт\n" +
                "Возраст детей: 7-10 лет\n" +
                "Когда? 16 января 2021 года в 16:30(время московское)\n" +
                "Где? Вход по ссылке https://cppl.webex.com/cppl/j.php?MTID=m95fc2d8df0d149dab93ec8c058ad0ff6\n" +
                "Регистрация не требуется!"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "Чудеса продолжаются!\n" +
                "Сегодня мы говорим СПАСИБО Деду Морозу, пожелавшему остаться неизвестным, за такие нужные для отряда подарки.\n" +
                "#спасибоотЛизаАлерт #БумерангДобра #ЛизаАлертЛипецк #ЛизаАлерт #LizaAlert"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "Внимание! Помогите найти человека!\n" +
                "Пропал #Коннов Сергей Александрович 41 год, г. #Ливны д. #Горностаевка #Ливенскийрайон #Орловскаяобласть\n" +
                "С 1 января 2021 года его местонахождение неизвестно.\n" +
                "Может нуждаться в медицинской помощи!\n" +
                "Тема на форуме: https://lizaalert.org/forum/viewtopic.php?f=222&t=42618\n" +
                "Инфорги: Iris (Ирина) 89624762607, Звонкая (Светлана) 89208202844.\n" +
                "#Пропал_человек #Поиск #ЛизаАлерт #Помощь #Помогите_найти_человека #ЛизаАлертОрел"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "Мы сами меняем мир вокруг нас, и какой это будет мир - решать нам. Помогая людям вокруг, вы убедитесь, что добро всегда возвращается.\n" +
                "Давайте все вместе запустим бумеранг добра в новый год!\n" +
                "#ЛизаАлерт #БумерангДобра #вместе\n" +
                "#LizaAlert #ЛизаАлертЛипецкаяобласть #ЛизаАлерт48\n" +
                "#ЛизаАлертЛипецк #помочьможеткаждый\n" +
                "#будьснами"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "Благодарим всех, кто поддерживал отряд #ЛизаАлерт в 2020 году и помогал нам стать ещё лучше!\n" +
                "Поздравляем с наступающим Новым годом!\n" +
                "Пусть 2021 год принесёт вам положительные эмоции, успех и поможет сотворить череду добрых дел!\n" +
                "Надеемся, в новом году мы вместе поможем спасти еще много жизней, и каждый потерявшийся человек вернется домой.\n" +
                "Спасибо за то, что вы с нами!\n" +
                "#ЛизаАлерт #LizaAlert #2021"));
        recyclerNewsItemList.add(new RecyclerNewsItem("LizaAlert", "Статистика заявок ДПСО Лиза Алерт Липецкой области за 2020 год:\n" +
                "Всего заявок - 201\n" +
                "Найден, жив - 141\n" +
                "Найден, погиб - 24\n" +
                "Родные найдены - 7\n" +
                "#ЛизаАлертЛипецк #ЛизаАлерт #Липецк #поисклюдей #Помогите_найти_человека #Липецкаяобласть"));

        // Подвесить на API

        adapter = new NewsAdapter(recyclerNewsItemList, root.getContext());
        recyclerView.setAdapter(adapter);


        recyclerView.setOnTouchListener(new OnSwipeTouchListener(getContext()) {
            public void onSwipeLeft() {
                // Добавить запрос разрешения на геолокацию (Спросить у Юры)
                @SuppressLint("ClickableViewAccessibility") Intent intent = new Intent(getContext(), MapsActivity.class);
                startActivity(intent);
            }
        });

        return root;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }
}
