package com.example.toolbarapp.ui.rating;

import java.io.Serializable;

public class Rating {
    private Integer number;
    private String
            login,
            count,
            imageUri;

    public Rating(Integer number, String login, String count, String imageUri) {
        this.number = number;
        this.login = login;
        this.count = count;
        this.imageUri = imageUri;
    }

    public Integer getNumber() {
        return number;
    }

    public String getLogin() {
        return login;
    }

    public String getCount() {
        return count;
    }

    public String getImageUri() {
        return imageUri;
    }
}
