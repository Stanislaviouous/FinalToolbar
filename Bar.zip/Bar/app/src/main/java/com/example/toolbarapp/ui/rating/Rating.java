package com.example.toolbarapp.ui.rating;

import java.io.Serializable;

public class Rating {
    private String number;
    private String
            login,
            count,
            imageUri;

    public Rating(String number, String login, String count, String imageUri) {
        this.number = number;
        this.login = login;
        this.count = count;
        this.imageUri = imageUri;
    }

    public String getNumber() {
        return number;
    }

    public String getLogin() {
        return login;
    }

    public String getCount() {
        return count;
    }

    public String getImageUri() {
        return imageUri;
    }
}
