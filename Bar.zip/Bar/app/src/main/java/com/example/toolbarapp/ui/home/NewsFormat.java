package com.example.toolbarapp.ui.home;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class NewsFormat {

    // Функция преобразования из общей даты в правильную
    String dateFormat(Long a){
        Date date = new Date(a*1000);
        SimpleDateFormat formater = new SimpleDateFormat("dd.MM.yyyy");
        SimpleDateFormat formater1 = new SimpleDateFormat("HH:mm");
        return formater1.format(date) + " " + formater.format(date);
    }

    // Функция праавильного показа строки
    String textFormat(String stroke){
        if (stroke.length() > 200){
            return stroke.substring(0,200) + " ..." + "\n" + "Посмотреть больше";
        }
        return stroke;
    }

    // Функция праавильного показа названия
    String titleFormat(String stroke){
        if (stroke.length() > 14){
            return stroke.substring(0,14) + " ...";
        }
        return stroke;
    }
}
