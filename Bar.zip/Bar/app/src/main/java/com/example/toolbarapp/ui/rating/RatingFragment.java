package com.example.toolbarapp.ui.rating;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.toolbarapp.R;
import com.example.toolbarapp.ui.profile.ProfileFragment;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class RatingFragment extends Fragment {

    private ArrayList<Rating> ratingList;
    private RatingViewModel ratingViewModel;
    String currentUserID = ProfileFragment.mAuth.getCurrentUser().getUid();
    private DatabaseReference rootRot;
    ListView listView;
    /*
    * */
    String loginRat, countRat, imageUriRat;
    Integer number;
    /*
    * */
    public View onCreateView(@NonNull final LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ratingViewModel = ViewModelProviders.of(this).get(RatingViewModel.class);
        View root = inflater.inflate(R.layout.fragment_rating, container, false);

        rootRot = FirebaseDatabase.getInstance().getReference();

        listView = root.findViewById(R.id.list_rating);
        ratingList = new ArrayList<>();

        String currentUserID = ProfileFragment.mAuth.getCurrentUser().getUid();
        rootRot.child("Users").child(currentUserID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("email").exists() && dataSnapshot.child("image").exists()) {
                    imageUriRat = (String) dataSnapshot.child("image").getValue();
                    countRat = (String) dataSnapshot.child("count").getValue();
                    loginRat = (String) dataSnapshot.child("login").getValue();

                    ratingList.add(new Rating(1, loginRat, countRat, imageUriRat));
                    final RatingAdapter ratingAdapter = new RatingAdapter(getContext(), R.layout.list_item, ratingList);
                    listView.setAdapter(ratingAdapter);

                } else {
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
        return root;
    }
    void ratingUpdate(){ // Дописать метод обновления
    }
}
