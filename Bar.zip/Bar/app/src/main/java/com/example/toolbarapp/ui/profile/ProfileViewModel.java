package com.example.toolbarapp.ui.profile;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileViewModel extends ViewModel {

    private MutableLiveData<String> mText;
    CircleImageView circleImageView;

    public void setCircleImageView(CircleImageView circleImageView) {
        this.circleImageView = circleImageView;
    }
}