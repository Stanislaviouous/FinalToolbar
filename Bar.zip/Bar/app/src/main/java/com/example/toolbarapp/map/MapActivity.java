package com.example.toolbarapp.map;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.toolbarapp.MainActivity;
import com.example.toolbarapp.MatesActivity;
import com.example.toolbarapp.R;
import com.example.toolbarapp.RegistrationActivity;


public class MapActivity extends AppCompatActivity {

    Button end;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        end = (Button) findViewById(R.id.endMap);

        end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MapActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

}
