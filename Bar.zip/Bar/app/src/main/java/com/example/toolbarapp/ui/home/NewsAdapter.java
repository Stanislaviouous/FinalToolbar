package com.example.toolbarapp.ui.home;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.toolbarapp.R;
import com.squareup.picasso.Picasso;
import de.hdodenhof.circleimageview.CircleImageView;

import java.util.ArrayList;
import java.util.List;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.ViewHolder>{


    private ArrayList<RecyclerNewsItem> listItems;
    RecyclerImageViewAdapter listOfImage;
    RecyclerVideoViewAdapter listOfVideo;
    ArrayList<String> stringArrayList;
    ArrayList<String> stringArrayListVideo;
    private Context mContext;
    static int ps;

    public NewsAdapter(ArrayList<RecyclerNewsItem> listItems, Context mContext) {
        this.listItems = listItems;
        this.mContext = mContext;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_news_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final RecyclerNewsItem item = listItems.get(position);

        Picasso.get().load(item.getGroupPhotoUrl()).into(holder.circleImageView);
        holder.title.setText(item.getGroupName());
        holder.date.setText(item.getDate());
        holder.text.setText(item.getText());

        stringArrayList = item.getMediaUrl();
        stringArrayListVideo = item.getVideos();

        if (stringArrayList.size() == 0){

        }
        if (stringArrayList.size() == 1){
            Picasso.get().load(stringArrayList.get(0)).into(holder.imageAll);
        }
        if (stringArrayList.size() > 1){
            holder.recyclerViewImage.setLayoutManager(new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false));
            holder.recyclerViewImage.setHasFixedSize(true);

            listOfImage = new RecyclerImageViewAdapter(mContext, stringArrayList);
            holder.recyclerViewImage.setAdapter(listOfImage);

        }

        if (stringArrayListVideo.size() == 0){

        }
        if (stringArrayListVideo.size() == 1){
            WebSettings webSettings = holder.webViewVideo.getSettings();
            webSettings.setJavaScriptEnabled(true);

            holder.webViewVideo.loadData("<iframe src=\"https://vk.com/video_ext.php?oid=7226707&id=171238460&hash=9068a2aa618144c7&hd=1\" width=\"" + 320 + "\" height=\""  + 180 +"\" frameborder=\"0\" allowfullscreen></iframe>",
                    "text/html", "UTF-8");
            /*Picasso.get().load(stringArrayList.get(0)).into(holder.imageAll);*/
        }
        if(stringArrayListVideo.size() > 1){

            WebSettings webSettings = holder.webViewVideo.getSettings();
            webSettings.setJavaScriptEnabled(true);

            holder.webViewVideo.loadData("<iframe src=\"https://vk.com/video_ext.php?oid=7226707&id=171238460&hash=9068a2aa618144c7&hd=1\" width=\"" + 320 + "\" height=\""  + 180 +"\" frameborder=\"0\" allowfullscreen></iframe>",
                    "text/html", "UTF-8");

            /*holder.getRecyclerViewVideo.setLayoutManager(new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false));
            holder.getRecyclerViewVideo.setHasFixedSize(true);

            listOfVideo = new RecyclerVideoViewAdapter(mContext, stringArrayListVideo);
            holder.getRecyclerViewVideo.setAdapter(listOfVideo);*/
        }

        /*holder.image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Picasso.get().load(stringArrayList.get(position)).into(holder.imageAll);
                 /*Log.d(TAG, "onClick: clicked on an image: " + mNames.get(position));

                    //// Менять главное фото

                    Toast.makeText(mContext, mNames.get(position), Toast.LENGTH_SHORT).show();
            }
        });*/

        holder.txtOptionDigit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popupMenu = new PopupMenu(mContext, holder.txtOptionDigit);
                popupMenu.inflate(R.menu.news_menu);
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {

                        switch (item.getItemId()) {
                            case R.id.menu_news_add:
                                // Добавить реальные методы
                                Toast.makeText(mContext, "Добавлено в задачи", Toast.LENGTH_LONG).show();
                                break;
                            case R.id.menu_news_call:
                                // Добавить реальные методы
                                Toast.makeText(mContext, "Связываемся", Toast.LENGTH_LONG).show();
                            case R.id.menu_news_save:
                                // Добавить реальные методы
                                notifyDataSetChanged();
                                Toast.makeText(mContext, "Сохранено", Toast.LENGTH_LONG).show();
                                break;
                            default:
                                break;
                        }
                        return false;
                    }
                });
                popupMenu.show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView txtOptionDigit;
        public CircleImageView circleImageView;
        public TextView title;
        public TextView date;
        public TextView text;
        public RecyclerView recyclerViewImage;
        public RecyclerView getRecyclerViewVideo;
        public ImageView imageAll;
        public ImageView image;
        public WebView webViewVideo;


        public ViewHolder(View itemView) {
            super(itemView);

            circleImageView = (CircleImageView) itemView.findViewById(R.id.circleImageView);
            title = (TextView) itemView.findViewById(R.id.txtTitle);
            date = (TextView) itemView.findViewById(R.id.txtdate);
            text = (TextView) itemView.findViewById(R.id.txtDescription);
            txtOptionDigit = (TextView) itemView.findViewById(R.id.txtOptionDigit);
            image = itemView.findViewById(R.id.recy_image);
            imageAll = itemView.findViewById(R.id.imageViewPos);
            recyclerViewImage = itemView.findViewById(R.id.recyclerViewImages);
            webViewVideo = itemView.findViewById(R.id.videoView);
            getRecyclerViewVideo = itemView.findViewById(R.id.recyclerViewVideo);
        }
    }
}
